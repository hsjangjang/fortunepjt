// Re-export from config/api.js for backwards compatibility
import apiClient from '@/config/api'

export default apiClient
