<template>
  <!-- Footer - Django base.html과 동일 -->
  <footer class="text-center text-muted py-5 mt-5 border-top" style="border-color: var(--glass-border) !important;">
    <div class="container">
      <p class="small">Made with <i class="fas fa-heart text-danger"></i> for your lucky day</p>
    </div>
  </footer>
</template>

<style scoped>
</style>
