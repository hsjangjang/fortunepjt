<template>
  <div class="fortune-detail">
    <h1>상세 운세</h1>
    <p>상세 운세 페이지입니다.</p>
  </div>
</template>

<script setup>
// 추후 구현 예정
</script>

<style scoped>
.fortune-detail {
  padding: 2rem;
  text-align: center;
}

h1 {
  color: #2c3e50;
  margin-bottom: 1rem;
}
</style>
