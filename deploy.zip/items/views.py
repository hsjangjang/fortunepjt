# items/views.py
# 레거시 템플릿 뷰는 모두 API로 대체되어 삭제됨
# API 엔드포인트: items/api_views.py 참조

# 이 파일은 하위 호환성을 위해 유지
# 실제 기능은 api_views.py에서 처리
